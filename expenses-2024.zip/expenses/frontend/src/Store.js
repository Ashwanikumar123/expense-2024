import { configureStore } from '@reduxjs/toolkit'
import userSlice from './pages/admin/users/features/userSlice'

export const store = configureStore({
  reducer: { users: userSlice },
})