import { Navigate } from "react-router-dom";

export default function PublicRoute({ element }) {
    const isAuth = JSON.parse(localStorage.getItem('auth'))
    return !isAuth ? (
        element
    ) : (
        <Navigate to="/" />
    );
}