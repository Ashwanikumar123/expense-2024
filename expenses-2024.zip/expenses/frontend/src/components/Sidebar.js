import { Link } from "react-router-dom";
import AdminRoutes from "../routers/AdminRoutes";

const Sidebar = () => {
    return (
        <aside className="-left-60 lg:left-0 lg:hidden xl:flex zzz lg:py-2 lg:pl-2 w-60 fixed flex z-40 top-0 h-screen transition-position overflow-hidden">
            <div className="aside lg:rounded-2xl flex-1 flex flex-col overflow-hidden dark:bg-slate-900">
                <div className="aside-brand flex flex-row h-14 items-center justify-between dark:bg-slate-900">
                    <div className="text-center flex-1 lg:text-left lg:pl-6 xl:text-center xl:pl-0">
                        <b className="font-black">Manage Expenses</b>
                    </div>
                    <button className="hidden lg:inline-block xl:hidden p-3">
                        <span className="inline-flex justify-center items-center w-6 h-6 ">
                            <svg
                                viewBox="0 0 24 24"
                                width={16}
                                height={16}
                                className="inline-block"
                            >
                                <path
                                    fill="currentColor"
                                    d="M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z"
                                />
                            </svg>
                        </span>
                    </button>
                </div>
                <div className="flex-1 overflow-y-auto overflow-x-hidden aside-scrollbars">
                    <ul className="">
                        {AdminRoutes.filter((item) => item?.meta?.isVisible !== false).map((item) => {
                            return (
                                <li>
                                    <Link
                                        className="flex cursor-pointer py-3 aside-menu-item dark:text-slate-300 dark:hover:text-white"
                                        to={item?.path}
                                    >
                                        <span className="inline-flex justify-center items-center w-16 h-6 flex-none">
                                            {item?.meta?.icon}
                                        </span>
                                        <span className="grow text-ellipsis line-clamp-1 pr-12">
                                            {item?.meta?.name}
                                        </span>
                                    </Link>
                                </li>
                            )
                        })}                       
                    </ul>
                </div>
            </div>
        </aside>

    )
}
export default Sidebar