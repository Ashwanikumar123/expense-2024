import { Navigate } from "react-router-dom";

export default function PrivateRoute({ element }) {
    const isAuth = JSON.parse(localStorage.getItem('auth'))
    return isAuth ? (
        element
    ) : (
        <Navigate to="/login" />
    );
}