import { Outlet } from "react-router-dom"
import Navbar from "../components/Navbar"
// import Footer from "../components/Footer"
import Sidebar from "../components/Sidebar"
const AdminLayout = () => {
    return (
        <div className="overflow-hidden lg:overflow-visible">
            <div className="xl:pl-60  pt-14 min-h-screen w-screen transition-position lg:w-auto bg-gray-50 dark:bg-slate-800 dark:text-slate-100">
                <Navbar/>
                <Sidebar/>
                <section className="p-6 xl:mx-auto">
                    <Outlet />
                </section>
                {/* <Footer/>               */}
            </div>
        </div>

    )
}

export default AdminLayout