import React, { Suspense } from 'react'
import Router from './routers/Router'
import { BrowserRouter } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'

const App = () => {
  return (
    <Suspense fallback={null}>
      <BrowserRouter>
        <Router />
      </BrowserRouter>
      <Toaster />
    </Suspense>
  )
}

export default App
