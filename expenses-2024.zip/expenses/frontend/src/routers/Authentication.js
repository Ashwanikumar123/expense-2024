import PublicRoute from "../components/PublicRoute"
import Login from "../pages/authentication/Login"
import Signup from "../pages/authentication/Signup"

const AuthenticationRoutes = [
    {
        path: '/login',
        element: <PublicRoute element={<Login />} />,
    },
    {
        path: '/register',
        element: <PublicRoute element={<Signup />} />,
    },
    {
        path: '/forgot-password',
        element: <PublicRoute element={<Login />} />,
    },
    {
        path: '/pages/reset-password',
        element: <PublicRoute element={<Login />} />,
    },
    {
        path: '/auth/not-auth',
        element: <PublicRoute element={<Login />} />,
    },
]

export default AuthenticationRoutes
