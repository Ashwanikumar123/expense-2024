import { useRoutes, Navigate } from 'react-router-dom'
import BlankLayout from '../layouts/BlankLayout'
import Error from '../pages/misc/Error'
import AdminLayout from '../layouts/AdminLayout'
import AuthenticationRoutes from './Authentication'
import PrivateRoute from '../components/PrivateRoute'
import AdminRoutes from './AdminRoutes'

const Router = () => {

    const getHomeRoute = () => {
        const isAuth = JSON.parse(localStorage.getItem('auth'))
        if (isAuth) {
            return '/admin/dashboard'
            //   return getHomeRouteForLoggedInUser(user.role)
        } else {
            return '/login'
        }
    }

    const routes = useRoutes([
        {
            path: '/',
            index: true,
            element: <Navigate replace to={getHomeRoute()} />
        },
        {
            path: '/user',
            element: <PrivateRoute element={<AdminLayout />} />,
            children: AdminRoutes
        },
        {
            path: '/admin',
            element: <PrivateRoute element={<AdminLayout />} />,
            children: AdminRoutes
        },
        {
            path: '*',
            element: <BlankLayout />,
            children: [{ path: '*', element: <Error /> }]
        },
        ...AuthenticationRoutes
    ])

    return routes
}

export default Router
