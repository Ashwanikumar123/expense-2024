import Dashboard from "../pages/admin/dashboard/index"
import UsersList from "../pages/admin/users"
import { FaHome, FaUser } from "react-icons/fa";
import { ImProfile } from "react-icons/im";
import { CiLogout } from "react-icons/ci";
import Login from "../pages/authentication/Login";
import AddUser from "../pages/admin/users/AddUser";

const AdminRoutes = [
    {
        path: 'dashboard',
        element: <Dashboard />,
        meta: {
            name: 'Dashboard',
            icon: <FaHome />
        },
    },
    {
        path: 'users',
        element: < UsersList />,
        meta: {
            name: 'Users',
            icon: <FaUser />
        },
    },
    {
        path: 'users/add',
        element: < AddUser />,
        meta: {
            isVisible : false
        },
    },
    {
        path: 'change-password',
        element: <Dashboard />,
        meta: {
            name: 'Change Password',
            icon: <ImProfile />
        },
    },
    {
        path: 'Logout',
        element: <Dashboard />,
        meta: {
            name: 'Logout',
            icon: <CiLogout />
        },
    },
]

export default AdminRoutes
