import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import api from '../../../../lib/http'

export const getUsers = createAsyncThunk(
    'admin/users',
    async () => {
        const response = await api.get('/admin/user')
        return response.data
    },
)

const initialState = {
    users: [],
    isLoading: false,
    error: ''
}

export const userSlice = createSlice({
    name: 'users',
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder.addCase(getUsers.pending, (state) => {
            state.isLoading = true
        })
        builder.addCase(getUsers.fulfilled, (state, action) => {
            state.isLoading = false
            state.users = action.payload
        })
        builder.addCase(getUsers.rejected, (state, action) => {
            state.isLoading = false
            state.error = action.error.message
        })
    },

})

// Action creators are generated for each case reducer function
// export const { increment, decrement, incrementByAmount } = counterSlice.actions

export default userSlice.reducer