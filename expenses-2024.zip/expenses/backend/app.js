const express = require("express");
const bodyParser = require("body-parser");
const connectDB = require('./config/db');
const authRoutes = require("./routes/auth");
const users = require("./routes/admin/users");
const cors = require("cors")
const PORT = 4000;

connectDB()

const app = express();
app.use(cors());

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use("/auth", authRoutes);
app.use("/admin/user", users);

app.listen(PORT, () => {
  console.log("Server started listening on PORT : " + PORT);
});