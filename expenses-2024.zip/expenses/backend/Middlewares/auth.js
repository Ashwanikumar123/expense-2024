const jwt = require("jsonwebtoken");

exports.auth = function (req, res, next) {

    try {
        const token = req.headers["Authorization"] || req.headers["authorization"];

        if (!token){
            return res.status(401).json({
                status: false,
                error: {
                    code: 'INVALID_TOKEN',
                    message: 'Your session has expired, Please log in again to continue',
                },
            });
        }

        if (token.indexOf("Bearer") !== 0) {
            return res.status(401).json({
                status: false,
                error: {
                    code: 'INVALID_TOKEN',
                    message: 'Your session has expired, Please log in again to continue',
                },
            });
        }

        const tokenString = token.split(" ")[1];
        jwt.verify(tokenString, '7285131817481B29BED5965010D78BD8BE39D07E40BBDA27158DA952BC717C28', (err, decodedToken) => {
            if (err) {
                console.log(err);
                return res.status(401).json({
                    status: false,
                    error: {
                        code: 'INVALID_TOKEN',
                        message: 'Your session has expired, Please log in again to continue',
                    },
                });
            }

            // console.log('decodedToken', decodedToken)
            // if (!decodedToken.data.role) {
            //     return res.status(403).json({
            //         status: false,
            //         message: "Role missing",
            //         error: {
            //             code: 'ROLE_NOT_FOUND',
            //             message: 'Role missing',
            //         },
            //     });
            // }

            // const userRole = decodedToken.role;
            // if (roles.indexOf(userRole) === -1) {
            //     return res.status(403).json({
            //         status: false,
            //         error: {
            //             code: 'NOT_AUTHORIZED',
            //             message: 'User not authorized',
            //         },
            //     });
            // }
            req.user = decodedToken.data;
            next();
        });
    } catch (err) {
        console.log(err);
        return res.status(500).json({
            status: false,
            error: {
                code: 'INVALID_TOKEN',
                message: 'Something went wrong, Please log in again to continue.',
            },
        });
    }
};
