
const User = require("../models/userModel");
const bcrypt = require("bcrypt")
const jwt = require('jsonwebtoken');

const signup = async (req, res) => {
    try {
        const { name, email, password } = req.body;

        const userExists = await User.findOne({ email });

        if (userExists) {
            return res.status(409).json({
                status: false,
                error: {
                    code: 'USER_ALREADY_EXISTS',
                    message: 'User already exists. Please choose a different email.',
                },
            });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const user = new User({
            name,
            email,
            password: hashedPassword,
        });

        await user.save();

        return res.status(201).json({
            status: true,
            message: 'Registration successful. Welcome!',
            data: {
                id: user._id,
                name: user.name,
                email: user.email,
                role: user.role,
            },
        });
    } catch (error) {
        return res.status(500).json({
            status: false,
            error: {
                code: 'INTERNAL_SERVER_ERROR',
                message: 'Something went wrong, Please try after some time.',
            },
        });
    }
};

const login = async (req, res) => {
    try {
        const { email, password } = req.body;

        // 1. Find if any account with that email exists in DB
        const user = await User.findOne({ email });

        // NOT FOUND - Throw error
        if (!user) {
            return res.status(404).json({
                status: false,
                error: {
                    code: 'USER_NOT_FOUND',
                    message: 'User not found!',
                },
            });
        }

        // 2. Throw error if account is not activated
        if (!user.status) {
            return res.status(404).json({
                status: false,
                error: {
                    code: 'ACCOUNT_NOT_ACTIVATED',
                    message: 'You must verify your email to activate your account',
                },
            });
        }

        // 3. Verify the password is valid
        const isValid = bcrypt.compareSync(password, user.password);

        if (!isValid) {
            return res.status(400).json({
                status: false,
                error: {
                    code: 'INVALID_CREDENTIALS',
                    message: "Credentials don't match. Please provide valid email and password!",
                },
            });
        }

        // Generate Access token
        const token = jwt.sign({
            exp: Math.floor(Date.now() / 1000) + 60 * 30,
            data: user,
        }, '7285131817481B29BED5965010D78BD8BE39D07E40BBDA27158DA952BC717C28');

        // user._doc.accessToken = token;
        // await user.save();

        // Success
        return res.status(200).json({
            status: true,
            message: 'User logged in successfully',
            data: {
                user,
                token
            }
        });

    } catch (err) {
        return res.status(500).json({
            status: false,
            error: {
                code: 'INTERNAL_SERVER_ERROR',
                message: 'Something went wrong. Please try again later.',
            },
        });
    }
};

module.exports = {
    signup,
    login
}