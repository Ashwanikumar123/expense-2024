
const User = require("../../models/userModel");

const usersList = async (req, res) => {
    try {
        const users = await User.find();
        return res.status(200).json({
            status: true,
            message: '',
            data: users,
        });
    } catch (error) {
        return res.status(500).json({
            status: false,
            error: {
                code: 'INTERNAL_SERVER_ERROR',
                message: 'Something went wrong, Please try after some time.',
            },
        });
    }
};

module.exports = {
    usersList
}