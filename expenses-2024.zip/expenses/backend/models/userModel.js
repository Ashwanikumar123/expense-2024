
const mongoose = require("mongoose");

// Define the schema for users
const userSchema = new mongoose.Schema(
  {
    // User's name
    name: {
      type: String,
      required: true
    },
    // User's email, must be unique
    email: {
      type: String,
      required: true,
      unique: true
    },
    // User's password
    password: {
      type: String,
      required: true
    },
    // Indicates whether the user is an admin or not
    role: {
      type: Number,
      required: true,
      default: 1
    },
    status: {
      type: Boolean,
      required: true,
      default: 1
    }
  },
  { timestamps: true } // Adds createdAt and updatedAt timestamps
);

// Create the User model
const User = mongoose.model('User', userSchema);

// Export the User model
module.exports = User;