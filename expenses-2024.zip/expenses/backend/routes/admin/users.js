const express = require("express");
const { usersList } = require("../../controllers/admin/userController");
const { auth } = require("../../Middlewares/auth");

const router = express.Router();

router.get("/", auth, usersList);

module.exports = router;